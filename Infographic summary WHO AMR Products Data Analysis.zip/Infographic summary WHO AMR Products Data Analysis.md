﻿**WHO AMR Products Data Analysis ![](Aspose.Words.1e217eea-1a40-4f57-846c-b4eb47af5c6a.001.png)**

1 ![](Aspose.Words.1e217eea-1a40-4f57-846c-b4eb47af5c6a.002.jpeg)
## **Distributions of product type** 
Non-traditional : 286 (42.8%) Antibiotics : 383 (57.2%) 

2 ![](Aspose.Words.1e217eea-1a40-4f57-846c-b4eb47af5c6a.003.jpeg)
## **Distributions of R&D phase** 
Phase I :- 310 ( 46.3% ) Phase II :- 186 ( 27.8% ) Phase III :-146 ( 21.8% ) Preregistration :- 27 ( 4.04% ) 

3 ![](Aspose.Words.1e217eea-1a40-4f57-846c-b4eb47af5c6a.004.jpeg)
## **Top Antibacterial Class** 
Bacteriophage  

4 ![](Aspose.Words.1e217eea-1a40-4f57-846c-b4eb47af5c6a.005.jpeg)
## **Top Indication** 
Gram negative infection 

5 ![](Aspose.Words.1e217eea-1a40-4f57-846c-b4eb47af5c6a.006.jpeg)
## **Top developers** 
Qpex GSK 
